/**
 * @file course.h
 * @author Zicheng Li 
 * @brief Create a struct named course and declare some function about course.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief Create a struct named course here, it has name, Code, Total students.
 * 
 */
typedef struct _course 
{
  char name[100];   /**< the name of course */
  char code[10];  /**< the code of course */
  Student *students; /**< a student pointer */
  int total_students; /**< the total number of students */
} Course;

// These are function declarations for course struct.
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


