/**
 * @file student.c
 * @author Zicheng Li 
 * @brief This is the student struct library, including definitions of Student function.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Add the grade for a student using dynamic memory allocation.
 * 
 * @param student Student pointer 
 * @param grade double 
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));  // First allocate 1 double memory if there is only one student.
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);   // If there are more than one grades, then expand one memory.
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief This is a function to calculate the average grades for each student using a for loop.
 * 
 * @param student Student pointer 
 * @return average with double type
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];  // Use a loop to give the total grades for student
  return total / ((double) student->num_grades);    // return total divided by numbers of grades.
}


/**
 * @brief This function will print the student type struct, with Name, ID, Grades, Average.
 * 
 * @param student Student pointer 
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++)  // Using a for loop to print everyone's grades.
    printf("%.2f ", student->grades[i]);   // Only print 2 decimal places of Grades.
  printf("\n");
  printf("Average: %.2f\n\n", average(student));  // Only print 2 decimal places of Average.
}

/**
 * @brief This function will generate some students with random names and grades.
 * 
 * @param grades int 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] =                                                        // Create a array with some first name.
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] =                                                         // Create a array with some last name.
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);         // Copy the first names randomly into struct new_student.
  strcpy(new_student->last_name, last_names[rand() % 24]);           // Copy the last names randomly into struct new_student.

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);  // Using a loop to add ID randomly.
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));      // Using a loop to add grade with random numbers to student. 
  }

  return new_student;
}