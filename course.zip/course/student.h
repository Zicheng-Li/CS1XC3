/**
 * 
 * @file student.h
 * @author Zicheng Li 
 * @brief The file for the student struct and function use with student.
 * @date 2022-04-11
 * 
 */

/**
 * @brief Create a struct called stduent, it has name, ID, Grades with a pointer type, Average.
 * 
 */
typedef struct _student 
{ 
  char first_name[50];  /**< the first name of student */
  char last_name[50]; /**< the last name of student */
  char id[11]; /**< the id of student */
  double *grades; /**< the grades of student */
  int num_grades; /**< how many grades of one student */
} Student;


// These are function declarations for student struct.
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
