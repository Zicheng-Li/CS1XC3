/**
 * @mainpage Course demonstration
 * 
 * In the main, it will run program that can:
 * 
 * - Print the Name, Code, Total students of the course.
 * - Print all the student in the course with their Name, ID, Grades, Average.
 * - Print the top sudent in the course.
 * - Print all the students that passed this course.
 * 
 * 
 * @file main.c
 * @author Zicheng Li 
 * @brief Runs a demonstration of a course name "Basics of Mathematics" and gives the student names and grades randomly.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief This this the main function that will runs the program.
 * 
 * @return none 
 */
int main()
{
  /**
   * @brief Assign one course memory for the course MATH101 and add the name and code of the course.
   * 
   * It calls the srand function to sets the seed for rand.
   * 
   */
  
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
/**
 * @brief Use a for loop to enroll the students by calling the enroll_student using the generate_random_student.
 * 
 */
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");        // Print the Top students
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);   //Use a loop to print all students that passed the course.
  
  return 0;
}