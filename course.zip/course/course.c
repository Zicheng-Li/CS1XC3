/**
 * @file course.c
 * @author Zicheng Li 
 * @brief This is the course struct library, including definitions of Course function.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief This function will take pointer course and student to make new memory for struct to add students into course.
 * 
 * @param course Course pointer 
 * @param student Student pointer
 * @return nothing
 */
 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));  // This is first-times memory allocation if there is only 1 students to add.
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); // If there is more than 1 student, then we can expand one memory.
  }
  course->students[course->total_students - 1] = *student; 
}

/**
 * @brief This funtion will print the course name, code, how many students and using a loop to call print_student function.
 * 
 * @param course Course pointer 
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief This function will use the average function to calculate the average of student and compare each one of them, finally return the Student who has the highest average.
 * 
 * @param course Course pointer 
 * @return Student* 
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)  // Using a for loop to calculate everyone's average.
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;  // Compare the average and save max average student.
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief This is a function to give how many students pass the course and return a dynamic memory Student struct called passing.
 * 
 * @param course Course pointer 
 * @param total_passing int for how many students had passed the course.
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++)   // using a loop to count how many students passed.
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));  // dynamic memory allocation.

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)   // Add each passed student to passing.
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}